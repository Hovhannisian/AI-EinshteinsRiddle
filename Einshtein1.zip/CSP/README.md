# CSP
Constraint Satisfaction Problem - Einstein's Riddle

The zebra puzzle is a well-known logic puzzle. Many versions of the puzzle exist, including a version published in Life International magazine on December 17, 1962. The March 25, 1963, issue of Life contained the solution and the names of several hundred successful solvers from around the world.

The Zebra puzzle has been used as a benchmark in the evaluation of computer algorithms for solving constraint satisfaction problems.

Recursive Backtracking Solver
